/*Multiplication of n*m and m*p Matrixs works in O(n*m*p) time*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

long long A[1100][1100],B[1100][1100],C[1100][1100];

int main()
{
	int n,m,p,i,j,k;
	scanf("%d%d%d",&n,&m,&p);
	for(i=1;i<=n;++i) for(j=1;j<=m;++j) scanf("%I64d",&A[i][j]);
	for(i=1;i<=m;++i) for(j=1;j<=p;++j) scanf("%I64d",&B[i][j]);
	int t0=clock();
	
	/***********************MATRIX_MUL*****************************/
	/*exchange order of loops will optimize memory performance*/
	/*This method will Speed up 2~4 times*/
	/*This function works in O(n*m*p) time*/
	for(i=1;i<=n;++i)
	for(k=1;k<=m;++k)
	{
		/*use register virable to raise speed.*/
		register long long temp=A[i][k];
		register int t;
		for(t=1;t<=p;++t)
			C[i][t]+=temp*B[k][t];
	}
	/**************************************************************/
	
	printf("%g s\n",1.0*(clock()-t0)/CLOCKS_PER_SEC);
	system("pause");
	for(i=1;i<=n;++i)
	{
		for(j=1;j<=p;++j)
			printf("%I64d ",C[i][j]);
		printf("\n");
	}
	return 0;
}
