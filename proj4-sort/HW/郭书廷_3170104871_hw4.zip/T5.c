#include <stdio.h>

/*This func work in O(n^2) time.*/
void SortIntegerArray(int* begin,int* end)
{
	int i,j,temp,n=end-begin;
	for(i=1;i<n;++i)
	{
		temp=begin[i];
		for(j=i-1;begin[j]>temp && j>=0;--j)
			begin[j+1]=begin[j];
		begin[j+1]=temp;
	} return ;
}

int a[11000];

int main()
{
	int i,n;
	scanf("%d",&n);
	for(i=0;i<n;++i) scanf("%d",&a[i]);
	SortIntegerArray(a,a+n);
	for(i=0;i<n;++i) printf("%d ",a[i]);
	printf("\n"); return 0;
}
