#include <stdio.h>

int RemoveZeroElements(int* A,const int N)
{
	int i,j;
	for(i=0,j=0;i<N;++i) if(A[i])A[j++]=A[i];
	for(i=j;i<N;++i) A[i]=0; return j;
}

int a[110000];

int main()
{
	int n,i; scanf("%d",&n);
	
	for(i=0;i<n;++i) scanf("%d",&a[i]);
	n=RemoveZeroElements(a,n);
	for(i=0;i<n;++i) printf("%d ",a[i]);
	
	printf("\n"); return 0;
}
