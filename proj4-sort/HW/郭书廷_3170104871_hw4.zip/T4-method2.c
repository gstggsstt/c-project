#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const int N=52;

int a[110],key[110];

int main()
{
	int i,j,temp; srand(time(0));
	for(i=1;i<=N;++i) a[i]=i;
	for(i=1;i<=N;++i) key[i]=rand();

	for(i=1;i<N;++i)
		for(j=1;j<=N-i;++j)
			if(key[j]>key[j+1])
			{
				temp=key[j],key[j]=key[j+1],key[j+1]=temp;
				temp=a[j],a[j]=a[j+1],a[j+1]=temp;
			}

	for(i=1;i<=N;++i) printf("%d ",a[i]);
	printf("\n"); return 0;
}
