#include <stdio.h>

int RemoveDuplicates(int * A,const int N)
{
	int i,j;
	for(i=1,j=1;i<N;++i) if(A[i]!=A[i-1])A[j++]=A[i];
	for(i=j;i<N;++i) A[i]=0; return j;
}

int a[110000];

int main()
{
	int i,n;
	scanf("%d",&n);

	for(i=0;i<n;++i) scanf("%d",&a[i]);
	n=RemoveDuplicates(a,n);
	for(i=0;i<n;++i) printf("%d ",a[i]);

	printf("\n"); return 0;
}
