#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const int N=52;
int a[110];

int main()
{
	int i; srand(time(0));

	for(i=1;i<=N;++i) a[i]=i;
	for(i=1;i<=N;++i)
	{
		int l=rand()%N+1,r=rand()%N+1;
		int temp=a[l]; a[l]=a[r],a[r]=temp;
	}

	for(i=1;i<=N;++i)
		printf("%d ",a[i]);
	printf("\n"); return 0;
}
